import React from "react";
import Avatar from "@material-ui/core/Avatar";
import { makeStyles } from "@material-ui/core/styles";
import Paper from "@material-ui/core/Paper";
import Grid from "@material-ui/core/Grid";
import Typography from "@material-ui/core/Typography";
import Divider from "@material-ui/core/Divider";

const useStyles = makeStyles(theme => ({
  root: {
    flexGrow: 1
  },
  icon: {
    padding: theme.spacing(2),
    textAlign: "center",
    color: theme.palette.text.secondary,
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    verticalAlign: "middle"
  },
  end: {
    padding: theme.spacing(2),
    color: theme.palette.text.secondary,
    display: "flex",
    justifyContent: "right",
    alignItems: "center",
    verticalAlign: "middle"
  }
}));

export default function GridItem() {
  const classes = useStyles();

  return (
    <div className={classes.root}>
      <Grid container spacing={3}>
        <Grid className={classes.icon} item xs={1}>
          <Avatar alt="Remy Sharp" src="/static/images/avatar/1.jpg" />
        </Grid>
        <Grid item xs={6}>
          <Typography variant="h5" component="h5" align="left">
            Project Name
          </Typography>
          <Typography variant="body2" component="p" align="left">
            Project Description
          </Typography>
        </Grid>
        <Grid className={classes.end} item xs={5}>
          <Typography variant="body2" component="p">
            Updated 5 hours ago...
          </Typography>
        </Grid>
        <Grid item xs={12}>
          <Divider />
        </Grid>
        <Grid className={classes.icon} item xs={1}>
          <Avatar alt="Remy Sharp" src="/static/images/avatar/1.jpg" />
        </Grid>
        <Grid item xs={6}>
          <Typography variant="h5" component="h5" align="left">
            Project Name
          </Typography>
          <Typography variant="body2" component="p" align="left">
            Project Description
          </Typography>
        </Grid>
        <Grid className={classes.end} item xs={5}>
          <Typography variant="body2" component="p">
            Updated 5 hours ago...
          </Typography>
        </Grid>
      </Grid>
    </div>
  );
}
