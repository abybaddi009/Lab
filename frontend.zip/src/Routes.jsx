import React from "react";
import axios from "axios";
import { Switch, Route, Redirect } from "react-router-dom";

// Views
import SignIn from "layouts/SignIn";

import Drawer from "layouts/Drawer";

function PrivateRoute({ component: Component, loggedIn, ...rest }) {
  return (
    <Route
      {...rest}
      render={props =>
        loggedIn === true ? (
          <Component {...props} />
        ) : (
          <Redirect
            to={{ pathname: "/login", state: { from: props.location } }}
          />
        )
      }
    />
  );
}

function Dashboard(props) {
  const [token, setToken] = React.useState(localStorage.getItem("token"));
  const [username, setUsername] = React.useState("");

  function getUserData() {
    if (token != null && token !== "") {
      axios
        .get("http://localhost:8000/api/projectlab/current_user/", {
          headers: {
            Authorization: `JWT ${token}`
          }
        })
        .then(res => {
          console.log("getuserdata: ", res.data.username);
          setUsername(res.data.username);
        })
        .catch(err => console.log(err));
    }
  }

  getUserData();

  return (
    <div>
      <h3>Hello, {username}</h3>
      <p>Your: {token}</p>
    </div>
  );
}

export default function Routes(props) {
  const [token, setToken] = React.useState(localStorage.getItem("token"));
  const [loggedIn, setLoggedIn] = React.useState(token ? true : false);
  const [errorMessage, setErrorMessage] = React.useState({
    username: [],
    password: [],
    non_field_errors: []
  });

  function handleLogin(e, username, password) {
    e.preventDefault();
    axios
      .post(`http://localhost:8000/token-auth/`, {
        username: username,
        password: password
      })
      .then(res => {
        if (res.status === 200) {
          const responseToken = res.data.token;
          localStorage.setItem("token", responseToken);
          setToken(responseToken);
          if (responseToken != null && responseToken !== "") setLoggedIn(true);
          console.log("Username: " + username);
          props.browserHistory.push("/");
        }
      })
      .catch(err => {
        setErrorMessage(err.response.data);
      });
  }

  function handleLogOff() {
    setToken(null);
    setLoggedIn(false);
    localStorage.removeItem("token");
  }

  return (
    <Switch>
      <Redirect exact from="/" to="/home" />
      <Route
        render={props => (
          <SignIn
            {...props}
            handleLogin={handleLogin}
            handleLogOff={handleLogOff}
            loggedIn={loggedIn}
            errorMessage={errorMessage}
          />
        )}
        exact
        path="/login"
      />
      <PrivateRoute path="/home" loggedIn={loggedIn} component={Drawer} />
    </Switch>
  );
}
