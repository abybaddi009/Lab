from django.urls import path
from rest_framework import routers

from .views import ProjectCL, ProjectRUD, TeamCL, TeamRUD

router = routers.DefaultRouter()
router.register(r'^projects/$', ProjectCL, 'ProjectCL')

urlpatterns = [
    path('api/', include(router.urls)),
    path("projects/", ProjectCL.as_view(), name="ProjectCL"),
    path("projects/<int:pk>/", ProjectRUD.as_view(), name="ProjectRUD"),
    path("teams/", TeamCL.as_view(), name="TeamCL"),
    path("teams/<int:pk>/", TeamRUD.as_view(), name="TeamRUD")
]
