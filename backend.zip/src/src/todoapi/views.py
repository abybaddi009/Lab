from django.shortcuts import render
from rest_framework import generics 

from .models import Project, Team
from .serializers import ProjectSerializer, TeamSerializer


class ProjectCL(generics.ListCreateAPIView):
    serializer_class = ProjectSerializer
    queryset = Project.objects.all()

class ProjectRUD(generics.RetrieveUpdateDestroyAPIView):
    serializer_class = ProjectSerializer
    queryset = Project.objects.all()

class TeamCL(generics.ListCreateAPIView):
    serializer_class = TeamSerializer
    queryset = Team.objects.all()

class TeamRUD(generics.RetrieveUpdateDestroyAPIView):
    serializer_class = TeamSerializer
    queryset = Team.objects.all()
