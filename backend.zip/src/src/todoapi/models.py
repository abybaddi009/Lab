from django.contrib.auth.models import Group
from django.db import models


class Team(Group):
    description = models.TextField()
    slug = models.SlugField(max_length=128)
    created_on = models.DateTimeField(auto_now_add=True)
    modified_on = models.DateTimeField(auto_now=True)

    objects = models.Manager()


# Create your models here.
class Project(models.Model):
    name = models.CharField(max_length=128)
    description = models.TextField()
    slug = models.SlugField(max_length=128)
    created_on = models.DateTimeField(auto_now_add=True)
    modified_on = models.DateTimeField(auto_now=True)
    team = models.ManyToManyField(Team)

    objects = models.Manager()
