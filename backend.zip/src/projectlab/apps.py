from django.apps import AppConfig


class ProjectlabConfig(AppConfig):
    name = 'projectlab'
