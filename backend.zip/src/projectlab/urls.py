from django.urls import path

from .views import ProjectCL, ProjectRUD, TeamCL, TeamRUD, current_user


urlpatterns = [
    path('current_user/', current_user),
    path("projects/", ProjectCL.as_view(), name="Project-CreateList"),
    path("projects/<int:pk>/", ProjectRUD.as_view(), name="Project-RetrieveUpdateDelete"),
    path("teams/", TeamCL.as_view(), name="Team-CreateList"),
    path("teams/<int:pk>/", TeamRUD.as_view(), name="Team-RetrieveUpdateDelete")
]
